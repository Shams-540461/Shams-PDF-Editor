import { Menu, X } from "lucide-react";
import { useState } from "react";

export const Route = createFileRoute('/')({
  component: HomePage,
})

// SVG Icons
const IconBg = () => (
  <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
    <polyline points="9 22 9 12 15 12 15 22"/>
    <path d="M9 7h6M7 12h.01M17 12h.01"/>
  </svg>
)

const IconPassport = () => (
  <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="3" width="18" height="18" rx="2"/>
    <circle cx="12" cy="10" r="3"/>
    <path d="M7 21v-1a5 5 0 0 1 10 0v1"/>
  </svg>
)

const IconPDF = () => (
  <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
    <polyline points="14 2 14 8 20 8"/>
    <line x1="16" y1="13" x2="8" y2="13"/>
    <line x1="16" y1="17" x2="8" y2="17"/>
    <polyline points="10 9 9 9 8 9"/>
  </svg>
)

const IconOCR = () => (
  <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2"/>
    <rect x="7" y="7" width="10" height="10" rx="1"/>
    <line x1="9" y1="11" x2="15" y2="11"/>
    <line x1="9" y1="14" x2="13" y2="14"/>
  </svg>
)

const IconUpload = () => (
  <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="16 16 12 12 8 16"/>
    <line x1="12" y1="12" x2="12" y2="21"/>
    <path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/>
  </svg>
)

const IconMenu = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <line x1="3" y1="6" x2="21" y2="6"/>
    <line x1="3" y1="12" x2="21" y2="12"/>
    <line x1="3" y1="18" x2="21" y2="18"/>
  </svg>
)

const IconClose = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <line x1="18" y1="6" x2="6" y2="18"/>
    <line x1="6" y1="6" x2="18" y2="18"/>
  </svg>
)

const IconCheck = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="20 6 9 17 4 12"/>
  </svg>
)

const IconArrow = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="5" y1="12" x2="19" y2="12"/>
    <polyline points="12 5 19 12 12 19"/>
  </svg>
)

const IconEmail = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
    <polyline points="22,6 12,13 2,6"/>
  </svg>
)

const IconPhone = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.61 3.38 2 2 0 0 1 3.58 1h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91A16 16 0 0 0 14 15.91l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
  </svg>
)

const IconLocation = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
    <circle cx="12" cy="10" r="3"/>
  </svg>
)

const IconStar = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" stroke="none">
    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
  </svg>
)

const LogoMark = () => (
  <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
    <polygon points="18,2 34,18 18,34 2,18" stroke="url(#logoGrad)" strokeWidth="1.5" fill="none"/>
    <polygon points="18,8 28,18 18,28 8,18" stroke="url(#logoGrad)" strokeWidth="1" fill="rgba(201,150,30,0.08)"/>
    <circle cx="18" cy="18" r="3" fill="url(#logoGrad)"/>
    <defs>
      <linearGradient id="logoGrad" x1="2" y1="2" x2="34" y2="34" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#c9961e"/>
        <stop offset="50%" stopColor="#e8c055"/>
        <stop offset="100%" stopColor="#c9961e"/>
      </linearGradient>
    </defs>
  </svg>
)

const GeomOrnament = ({ size = 120 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 120 120" fill="none" opacity="0.3">
    <polygon points="60,4 116,60 60,116 4,60" stroke="rgba(201,150,30,0.5)" strokeWidth="0.8" fill="none"/>
    <polygon points="60,16 104,60 60,104 16,60" stroke="rgba(201,150,30,0.35)" strokeWidth="0.8" fill="none"/>
    <polygon points="60,28 92,60 60,92 28,60" stroke="rgba(201,150,30,0.25)" strokeWidth="0.8" fill="none"/>
    <polygon points="60,40 80,60 60,80 40,60" stroke="rgba(201,150,30,0.2)" strokeWidth="0.8" fill="none"/>
    <line x1="4" y1="60" x2="116" y2="60" stroke="rgba(201,150,30,0.2)" strokeWidth="0.5"/>
    <line x1="60" y1="4" x2="60" y2="116" stroke="rgba(201,150,30,0.2)" strokeWidth="0.5"/>
    <line x1="14" y1="14" x2="106" y2="106" stroke="rgba(201,150,30,0.15)" strokeWidth="0.5"/>
    <line x1="106" y1="14" x2="14" y2="106" stroke="rgba(201,150,30,0.15)" strokeWidth="0.5"/>
    <circle cx="60" cy="60" r="8" stroke="rgba(201,150,30,0.4)" strokeWidth="0.8" fill="none"/>
    <circle cx="60" cy="60" r="2" fill="rgba(201,150,30,0.6)"/>
  </svg>
)

const tools = [
  {
    id: 'bg-remover',
    icon: <IconBg />,
    name: 'Background Remover',
    arabicLabel: 'إزالة الخلفية',
    desc: 'Remove any background instantly with AI precision. Perfect for product shots, portraits, and professional headshots.',
    features: ['One-click removal', 'HD quality output', 'Transparent PNG export'],
    tag: 'Most Popular',
  },
  {
    id: 'passport',
    icon: <IconPassport />,
    name: 'Passport Photo Maker',
    arabicLabel: 'صورة جواز السفر',
    desc: 'Generate compliant passport and visa photos for UAE, US, UK, and international standards with perfect sizing.',
    features: ['50+ country formats', 'Auto background swap', 'Print-ready layout'],
    tag: 'New',
  },
  {
    id: 'pdf-tools',
    icon: <IconPDF />,
    name: 'PDF Tools Suite',
    arabicLabel: 'أدوات PDF',
    desc: 'Merge, split, compress, convert, and secure your PDF documents in seconds. No software installation required.',
    features: ['Merge & split PDFs', 'Compress up to 90%', 'Word/Image conversion'],
    tag: null,
  },
  {
    id: 'ocr',
    icon: <IconOCR />,
    name: 'OCR Text Scanner',
    arabicLabel: 'ماسح النصوص',
    desc: 'Extract text from images and scanned documents with high accuracy. Supports Arabic, English, and 40+ languages.',
    features: ['Arabic & English', 'Table detection', 'Editable output'],
    tag: 'AI-Powered',
  },
]

const steps = [
  { num: '01', title: 'Upload Your File', desc: 'Drag and drop or select any image, PDF, or document from your device.' },
  { num: '02', title: 'Select Your Tool', desc: 'Choose from our suite of AI-powered tools tailored to your specific need.' },
  { num: '03', title: 'Download Result', desc: 'Your processed file is ready in seconds. Download in your preferred format.' },
]

const stats = [
  { value: 'Smart Tools', label: 'Files Processed' },
  { value: 'Secure Use', label: 'Accuracy Rate' },
  { value: '47', label: 'Languages Supported' },
  { value: '<3s', label: 'Average Processing' },
]

function useIntersection(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); obs.disconnect() } },
      { threshold }
    )
    obs.observe(el)
    return () => obs.disconnect()
  }, [threshold])

  return { ref, visible }
}

function AnimSection({ children, className = '', delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const { ref, visible } = useIntersection(0.08)
  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0)' : 'translateY(28px)',
        transition: `opacity 0.8s cubic-bezier(0.16,1,0.3,1) ${delay}ms, transform 0.8s cubic-bezier(0.16,1,0.3,1) ${delay}ms`,
      }}
    >
      {children}
    </div>
  )
}

function ToolCard({ tool, index }: { tool: typeof tools[0]; index: number }) {
  const { ref, visible } = useIntersection(0.05)
  return (
    <div
      ref={ref}
      className="tool-card gold-border-subtle rounded-2xl p-6 flex flex-col gap-4"
      style={{
        background: 'linear-gradient(135deg, rgba(21,24,38,0.9), rgba(15,18,32,0.95))',
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0)' : 'translateY(32px)',
        transition: `opacity 0.7s cubic-bezier(0.16,1,0.3,1) ${index * 120}ms, transform 0.7s cubic-bezier(0.16,1,0.3,1) ${index * 120}ms`,
      }}
    >
      <div className="flex items-start justify-between">
        <div className="tool-icon-wrap" style={{ color: 'rgba(201,150,30,0.9)' }}>
          {tool.icon}
        </div>
        {tool.tag && (
          <span className="badge-gold rounded-full px-3 py-1 text-xs">{tool.tag}</span>
        )}
      </div>

      <div>
        <h3 style={{ fontFamily: 'var(--font-heading)', fontWeight: 600, fontSize: '1.05rem', color: 'var(--color-cream)', marginBottom: '2px' }}>
          {tool.name}
        </h3>
        <p style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: '0.85rem', color: 'rgba(201,150,30,0.5)', marginBottom: '10px' }}>
          {tool.arabicLabel}
        </p>
        <p style={{ color: 'rgba(245,240,230,0.55)', fontSize: '0.875rem', lineHeight: '1.70', fontWeight: 300 }}>
          {tool.desc}
        </p>
      </div>

      <div className="flex flex-col gap-2 mt-auto">
        {tool.features.map((f) => (
          <div key={f} className="flex items-center gap-2">
            <span style={{ color: 'rgba(201,150,30,0.7)' }}><IconCheck /></span>
            <span style={{ fontSize: '0.8rem', color: 'rgba(245,240,230,0.5)', fontWeight: 300 }}>{f}</span>
          </div>
        ))}
      </div>

      <button className="btn-gold rounded-xl px-4 py-2.5 mt-2 flex items-center justify-center gap-2 w-full">
        Try Tool <IconArrow />
      </button>
    </div>
  )
}

function UploadSection() {
  const [dragging, setDragging] = useState(false)
  const [fileName, setFileName] = useState<string | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setDragging(false)
    const file = e.dataTransfer.files[0]
    if (file) setFileName(file.name)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) setFileName(file.name)
  }

  return (
    <section id="upload" style={{ padding: '100px 0', position: 'relative', background: 'var(--color-dusk)' }}>
      <div className="section-glow-left" style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }} />
      <div className="geo-pattern" style={{ position: 'absolute', inset: 0, pointerEvents: 'none', opacity: 0.5 }} />

      <div style={{ maxWidth: '800px', margin: '0 auto', padding: '0 24px', position: 'relative', zIndex: 1 }}>
        <AnimSection className="text-center mb-12">
          <span className="badge-gold rounded-full px-4 py-1.5 inline-block mb-4">Quick Start</span>
          <h2 style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(2rem, 5vw, 3rem)',
            fontWeight: 300,
            color: 'var(--color-cream)',
            lineHeight: 1.2,
            marginBottom: '16px',
          }}>
            Upload & Transform
          </h2>
          <p style={{ color: 'rgba(245,240,230,0.5)', fontSize: '1rem', fontWeight: 300 }}>
            Drop any file to begin. Our AI processes it instantly.
          </p>
        </AnimSection>

        <AnimSection delay={150}>
          <div
            className={`upload-zone rounded-2xl ${dragging ? 'active' : ''}`}
            onDragOver={(e) => { e.preventDefault(); setDragging(true) }}
            onDragLeave={() => setDragging(false)}
            onDrop={handleDrop}
            onClick={() => fileRef.current?.click()}
            style={{ cursor: 'pointer' }}
          >
            <div className="upload-zone-inner rounded-2xl" style={{ padding: '60px 32px' }}>
              <div className="flex flex-col items-center gap-4">
                <div style={{
                  color: dragging ? 'rgba(232,192,85,0.9)' : 'rgba(201,150,30,0.5)',
                  transition: 'color 0.3s ease, transform 0.3s ease',
                  transform: dragging ? 'translateY(-6px) scale(1.1)' : 'none',
                }}>
                  <IconUpload />
                </div>

                {fileName ? (
                  <div className="text-center">
                    <p style={{ fontFamily: 'var(--font-heading)', fontSize: '0.9rem', color: 'rgba(232,192,85,0.9)', marginBottom: '4px' }}>
                      {fileName}
                    </p>
                    <p style={{ fontSize: '0.8rem', color: 'rgba(245,240,230,0.4)', fontWeight: 300 }}>File ready — select a tool below</p>
                  </div>
                ) : (
                  <div className="text-center">
                    <p style={{ fontFamily: 'var(--font-heading)', fontSize: '1rem', color: 'rgba(245,240,230,0.7)', marginBottom: '6px' }}>
                      {dragging ? 'Release to upload' : 'Drag & drop your file here'}
                    </p>
                    <p style={{ fontSize: '0.82rem', color: 'rgba(245,240,230,0.35)', fontWeight: 300 }}>
                      PNG, JPG, PDF, TIFF — up to 50MB
                    </p>
                  </div>
                )}

                <button
                  className="btn-outline-gold rounded-xl px-6 py-2.5"
                  onClick={(e) => { e.stopPropagation(); fileRef.current?.click() }}
                >
                  Browse Files
                </button>
              </div>
            </div>
          </div>
          <input ref={fileRef} type="file" style={{ display: 'none' }} onChange={handleChange} accept="image/*,.pdf" />
        </AnimSection>

        <AnimSection delay={250} className="mt-8">
          <p style={{ textAlign: 'center', fontSize: '0.78rem', color: 'rgba(245,240,230,0.3)', fontFamily: 'var(--font-heading)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: '16px' }}>
            Or select a tool directly
          </p>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px' }}>
            {tools.map((t) => (
              <button
                key={t.id}
                className="btn-outline-gold rounded-xl p-3 flex items-center gap-3"
                style={{ textAlign: 'left', textTransform: 'none', letterSpacing: '0', fontSize: '0.85rem', fontWeight: 400 }}
              >
                <span style={{ color: 'rgba(201,150,30,0.7)', flexShrink: 0 }}>{t.icon}</span>
                <span style={{ color: 'rgba(245,240,230,0.7)' }}>{t.name}</span>
              </button>
            ))}
          </div>
        </AnimSection>
      </div>
    </section>
  )
}

function ContactSection() {
  const [form, setForm] = useState({ name: '', email: '', message: '' })
  const [sent, setSent] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSent(true)
    setTimeout(() => setSent(false), 4000)
    setForm({ name: '', email: '', message: '' })
  }

  return (
    <section id="contact" style={{ padding: '100px 0', position: 'relative', background: 'var(--color-void)' }}>
      <div className="section-glow-right" style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }} />

      <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 24px', position: 'relative', zIndex: 1 }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '60px', alignItems: 'start' }}>

          <AnimSection style={{ position: 'relative' }}>
            <span className="badge-gold rounded-full px-4 py-1.5 inline-block mb-5">Get In Touch</span>
            <h2 style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(2rem, 5vw, 3rem)',
              fontWeight: 300,
              color: 'var(--color-cream)',
              lineHeight: 1.15,
              marginBottom: '20px',
            }}>
              We'd love to<br />
              <em style={{ fontStyle: 'italic' }}>hear from you</em>
            </h2>
            <p style={{ color: 'rgba(245,240,230,0.5)', fontSize: '0.95rem', lineHeight: 1.7, fontWeight: 300, marginBottom: '36px' }}>
              Have a question, a business inquiry, or a custom project in mind? Our team in the UAE is ready to assist.
            </p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              {[
                { icon: <IconEmail />, label: 'Email', value: 'support@shamswmalik.com' },
                { icon: <IconPhone />, label: 'Phone', value: '+971 568802521' },
                { icon: <IconLocation />, label: 'Location', value: 'Al Tayer Building Office 47, Satwa, Dubai, United Arab Emirates' },
              ].map((item) => (
                <div key={item.label} style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                  <div className="tool-icon-wrap" style={{ width: 42, height: 42, borderRadius: '10px', color: 'rgba(201,150,30,0.8)', flexShrink: 0 }}>
                    {item.icon}
                  </div>
                  <div>
                    <p style={{ fontSize: '0.72rem', color: 'rgba(201,150,30,0.6)', fontFamily: 'var(--font-heading)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: '2px' }}>
                      {item.label}
                    </p>
                    <p style={{ fontSize: '0.9rem', color: 'rgba(245,240,230,0.7)', fontWeight: 300 }}>{item.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </AnimSection>

          <AnimSection delay={150}>
            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              {[
                { key: 'name', label: 'Full Name', type: 'text', placeholder: 'Your name' },
                { key: 'email', label: 'Email Address', type: 'email', placeholder: 'you@example.com' },
              ].map(({ key, label, type, placeholder }) => (
                <div key={key}>
                  <label style={{ display: 'block', fontSize: '0.72rem', color: 'rgba(201,150,30,0.6)', fontFamily: 'var(--font-heading)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: '8px' }}>
                    {label}
                  </label>
                  <input
                    type={type}
                    required
                    className="form-input w-full rounded-xl px-4 py-3"
                    placeholder={placeholder}
                    value={form[key as 'name' | 'email']}
                    onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                    style={{ fontFamily: 'var(--font-body)', fontSize: '0.9rem' }}
                  />
                </div>
              ))}
              <div>
                <label style={{ display: 'block', fontSize: '0.72rem', color: 'rgba(201,150,30,0.6)', fontFamily: 'var(--font-heading)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: '8px' }}>
                  Message
                </label>
                <textarea
                  required
                  rows={5}
                  className="form-input w-full rounded-xl px-4 py-3"
                  placeholder="Tell us about your project or question..."
                  value={form.message}
                  onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
                  style={{ fontFamily: 'var(--font-body)', fontSize: '0.9rem', resize: 'vertical' }}
                />
              </div>

              <button type="submit" className="btn-gold rounded-xl px-6 py-3.5 flex items-center justify-center gap-2">
                {sent ? (
                  <span style={{ display: 'flex', alignItems: 'center', gap: '8px' }}><IconCheck /> Message Sent</span>
                ) : (
                  <span style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>Send Message <IconArrow /></span>
                )}
              </button>

              {sent && (
                <p style={{ textAlign: 'center', fontSize: '0.82rem', color: 'rgba(201,150,30,0.7)', fontWeight: 300 }}>
                  Thank you — we'll be in touch within 24 hours.
                </p>
              )}
            </form>
          </AnimSection>
        </div>
      </div>
    </section>
  )
}

function HomePage() {
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <>
      <button
  onClick={() => setMenuOpen(!menuOpen)}
  className="md:hidden"
  style={{ color: "#d4af37", fontSize: "28px" }}
>
  {menuOpen ? <X size={28} /> : <Menu size={28} />}
</button>

{menuOpen && (
  <div>
    className="md:hidden"
    style={{
      position: "absolute",
      top: "80px",
      left: "0",
      right: "0",
      background: "#050505",
      padding: "20px",
      display: "flex",
      flexDirection: "column",
      gap: "18px",
      borderBottom: "1px solid rgba(212,175,55,0.3)",
      zIndex: 9999
    }}
  >

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  
    const navLinks = [
    { href: '#tools', label: 'Tools' },
    { href: '#how-it-works', label: 'How It Works' },
    { href: '#about', label: 'About' },
    { href: '#contact', label: 'Contact' },
  ]

  return (
    <div className="noise" style={{ minHeight: '100vh', background: 'var(--color-void)' }}>

      {/* NAV */}
      <nav
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          zIndex: 100,
          transition: 'all 0.4s ease',
          padding: scrolled ? '12px 0' : '20px 0',
        }}
        className={scrolled ? 'nav-blur' : ''}
      >
        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <a href="#" style={{ display: 'flex', alignItems: 'center', gap: '12px', textDecoration: 'none' }}>
            <img src="/logo.png" alt="SSS Logo" style={{ width: "70px", height: "70px", borderRadius: "18px" }} />
            <div>
              <span style={{ display: 'block', fontFamily: 'var(--font-heading)', fontWeight: 700, fontSize: '0.95rem', color: 'var(--color-cream)', letterSpacing: '0.02em' }}>
                Shams Smart
              </span>
              <span style={{ display: 'block', fontFamily: 'var(--font-heading)', fontSize: '0.65rem', color: 'rgba(201,150,30,0.7)', letterSpacing: '0.18em', textTransform: 'uppercase' }}>
                Services
              </span>
            </div>
          </a>

          <div className="hidden md:flex" style={{ alignItems: 'center', gap: '32px' }}>
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: '0.8rem',
                  fontWeight: 500,
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'rgba(245,240,230,0.55)',
                  textDecoration: 'none',
                  transition: 'color 0.3s ease',
                }}
                onMouseEnter={e => (e.currentTarget.style.color = 'rgba(232,192,85,0.9)')}
                onMouseLeave={e => (e.currentTarget.style.color = 'rgba(245,240,230,0.55)')}
              >
                {link.label}
              </a>
            ))}
            <a href="#upload" className="btn-gold rounded-xl px-5 py-2" style={{ textDecoration: 'none' }}>
              Try Free
            </a>
          </div>

          <button
            className="md:hidden"
            style={{ background: 'none', border: 'none', color: 'var(--color-cream)', cursor: 'pointer', padding: '4px' }}
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? <IconClose /> : <IconMenu />}
          </button>
        </div>

        {menuOpen && (
          <div className="mobile-menu md:hidden" style={{ padding: '20px 24px 28px' }}>
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMenuOpen(false)}
                style={{
                  display: 'block',
                  fontFamily: 'var(--font-heading)',
                  fontSize: '1rem',
                  fontWeight: 500,
                  letterSpacing: '0.05em',
                  color: 'rgba(245,240,230,0.7)',
                  textDecoration: 'none',
                  padding: '12px 0',
                  borderBottom: '1px solid rgba(201,150,30,0.08)',
                }}
              >
                {link.label}
              </a>
            ))}
            <a href="#upload" className="btn-gold rounded-xl px-5 py-3 inline-block mt-4" style={{ textDecoration: 'none' }} onClick={() => setMenuOpen(false)}>
              Try Free
            </a>
          </div>
        )}
      </nav>

      {/* HERO */}
      <section className="hero-glow" style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', position: 'relative', overflow: 'hidden', paddingTop: '80px' }}>
        <div className="orb orb-1" style={{ position: 'absolute', width: 500, height: 500, top: '-100px', left: '-100px', opacity: 0.6 }} />
        <div className="orb orb-2" style={{ position: 'absolute', width: 350, height: 350, bottom: '0', right: '-50px', opacity: 0.5 }} />
        <div className="orb orb-3" style={{ position: 'absolute', width: 200, height: 200, top: '40%', right: '20%', opacity: 0.4 }} />

        <div style={{ position: 'absolute', right: '-60px', top: '50%', transform: 'translateY(-50%)', opacity: 0.12 }}>
          <GeomOrnament size={500} />
        </div>

        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 24px', position: 'relative', zIndex: 1, width: '100%' }}>
          <div style={{ maxWidth: '760px' }}>
            <div className="animate-reveal-fade" style={{ marginBottom: '24px' }}>
              <span className="badge-gold rounded-full px-4 py-1.5 inline-flex items-center gap-2">
                <span style={{ display: 'flex', gap: '2px' }}>
                  {[1,2,3,4,5].map(i => <span key={i} style={{ color: 'rgba(201,150,30,0.8)' }}><IconStar /></span>)}
                </span>
                Trusted by Built for UAE users across the UAE
              </span>
            </div>

            <h1
              className="animate-reveal-up delay-100"
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(3rem, 8vw, 6.5rem)',
                fontWeight: 300,
                lineHeight: 1.05,
                color: 'var(--color-cream)',
                marginBottom: '0',
                letterSpacing: '-0.01em',
              }}
            >
              Smart AI Tools<br />
              <span className="gold-text" style={{ fontStyle: 'italic' }}>for Every Need</span>
            </h1>

            <p
              className="animate-reveal-up delay-300"
              style={{
                marginTop: '28px',
                color: 'rgba(245,240,230,0.5)',
                fontSize: 'clamp(1rem, 2.5vw, 1.15rem)',
                lineHeight: 1.75,
                fontWeight: 300,
                maxWidth: '560px',
              }}
            >
              Professional-grade background removal, passport photo creation, PDF editing, and OCR scanning — powered by AI, designed for UAE professionals.
            </p>

            <div className="animate-reveal-up delay-500" style={{ marginTop: '40px', display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: '16px' }}>
              <a href="#upload" className="btn-gold rounded-xl px-8 py-3.5" style={{ textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: '8px' }}>
                Start for Free <IconArrow />
              </a>
              <a href="#tools" className="btn-outline-gold rounded-xl px-8 py-3.5" style={{ textDecoration: 'none' }}>
                Explore Tools
              </a>
            </div>

            <div
              className="animate-reveal-up delay-700"
              style={{ display: 'flex', flexWrap: 'wrap', gap: '32px', marginTop: '56px' }}
            >
              {stats.map((s) => (
                <div key={s.label}>
                  <div style={{ fontFamily: 'var(--font-heading)', fontWeight: 700, fontSize: 'clamp(1.4rem, 3vw, 2rem)', color: 'var(--color-gold-300)' }}>
                    {s.value}
                  </div>
                  <div style={{ fontSize: '0.78rem', color: 'rgba(245,240,230,0.4)', letterSpacing: '0.06em', fontFamily: 'var(--font-heading)', textTransform: 'uppercase' }}>
                    {s.label}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div style={{ position: 'absolute', bottom: '32px', left: '50%', transform: 'translateX(-50%)' }}>
          <div style={{ width: '1px', height: '40px', background: 'linear-gradient(to bottom, transparent, rgba(201,150,30,0.4))', animation: 'pulse-glow 2s ease-in-out infinite' }} />
        </div>
      </section>

      {/* TOOLS */}
      <section id="tools" style={{ padding: '100px 0', position: 'relative' }}>
        <div className="star-pattern" style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }} />

        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 24px', position: 'relative', zIndex: 1 }}>
          <AnimSection className="text-center mb-16">
            <span className="badge-gold rounded-full px-4 py-1.5 inline-block mb-4">AI-Powered Suite</span>
            <h2 style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(2rem, 5vw, 3.5rem)',
              fontWeight: 300,
              color: 'var(--color-cream)',
              lineHeight: 1.2,
              marginBottom: '16px',
            }}>
              Four tools, infinite<br />
              <em className="gold-text">possibilities</em>
            </h2>
            <p style={{ color: 'rgba(245,240,230,0.45)', fontSize: '1rem', fontWeight: 300, maxWidth: '500px', margin: '0 auto' }}>
              Each tool is built for precision and speed — from UAE visa photos to scanned Arabic contracts.
            </p>
          </AnimSection>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '20px' }}>
            {tools.map((tool, i) => (
              <ToolCard key={tool.id} tool={tool} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* UPLOAD */}
      <UploadSection />

      {/* HOW IT WORKS */}
      <section id="how-it-works" style={{ padding: '100px 0', position: 'relative', overflow: 'hidden' }}>
        <div className="section-glow-left" style={{ position: 'absolute', inset: 0 }} />
        <div style={{ position: 'absolute', right: '-80px', bottom: '-80px', opacity: 0.07 }}>
          <GeomOrnament size={400} />
        </div>

        <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 24px', position: 'relative', zIndex: 1 }}>
          <AnimSection className="text-center mb-16">
            <span className="badge-gold rounded-full px-4 py-1.5 inline-block mb-4">Process</span>
            <h2 style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(2rem, 5vw, 3.5rem)',
              fontWeight: 300,
              color: 'var(--color-cream)',
              lineHeight: 1.2,
            }}>
              Three steps to<br />
              <em className="gold-text">perfection</em>
            </h2>
          </AnimSection>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '32px' }}>
            {steps.map((step, i) => (
              <AnimSection key={step.num} delay={i * 150}>
                <div className="stat-card rounded-2xl p-8" style={{ position: 'relative', overflow: 'hidden' }}>
                  <div className="arabic-deco" style={{ position: 'absolute', top: '-20px', right: '-10px' }}>
                    {step.num}
                  </div>
                  <div style={{ position: 'relative', zIndex: 1 }}>
                    <div className="step-number mb-4">{step.num}</div>
                    <h3 style={{ fontFamily: 'var(--font-heading)', fontWeight: 600, fontSize: '1.1rem', color: 'var(--color-cream)', marginBottom: '12px' }}>
                      {step.title}
                    </h3>
                    <p style={{ color: 'rgba(245,240,230,0.5)', fontSize: '0.9rem', lineHeight: 1.7, fontWeight: 300 }}>
                      {step.desc}
                    </p>
                  </div>
                </div>
              </AnimSection>
            ))}
          </div>
        </div>
      </section>

      {/* ABOUT */}
      <section id="about" style={{ padding: '100px 0', background: 'var(--color-dusk)', position: 'relative', overflow: 'hidden' }}>
        <div className="geo-pattern" style={{ position: 'absolute', inset: 0, opacity: 0.4 }} />

        <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 24px', position: 'relative', zIndex: 1 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '60px', alignItems: 'center' }}>

            <AnimSection>
              <div style={{ position: 'relative' }}>
                <div className="about-frame rounded-2xl p-8" style={{ position: 'relative', overflow: 'hidden' }}>
                  <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: 0.25 }}>
                    <GeomOrnament size={320} />
                  </div>
                  <div style={{ position: 'relative', zIndex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '32px' }}>
                      <img src="/logo.png" alt="SSS Logo" style={{ width: "70px", height: "70px", borderRadius: "18px" }} />
                      <div>
                        <p style={{ fontFamily: 'var(--font-heading)', fontWeight: 700, fontSize: '1.1rem', color: 'var(--color-cream)' }}>Shams Smart Services</p>
                        <p style={{ fontSize: '0.78rem', color: 'rgba(201,150,30,0.6)', letterSpacing: '0.1em', textTransform: 'uppercase', fontFamily: 'var(--font-heading)' }}>Dubai, UAE</p>
                      </div>
                    </div>

                    <div className="gold-line mb-6" />

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                      {[
                        { n: 'AI', l: 'Smart Tools' },
                        { n: 'UAE', l: 'Focused' },
                        { n: '24/7', l: 'Available' },
                        { n: 'Secure', l: 'Service' },
                      ].map(s => (
                        <div key={s.l} className="stat-card rounded-xl p-4 text-center">
                          <div style={{ fontFamily: 'var(--font-heading)', fontWeight: 700, fontSize: '1.4rem', color: 'var(--color-gold-300)' }}>{s.n}</div>
                          <div style={{ fontSize: '0.72rem', color: 'rgba(245,240,230,0.45)', letterSpacing: '0.08em', textTransform: 'uppercase', fontFamily: 'var(--font-heading)' }}>{s.l}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </AnimSection>

            <AnimSection delay={200}>
              <span className="badge-gold rounded-full px-4 py-1.5 inline-block mb-5">About Us</span>
              <h2 style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(2rem, 4vw, 3rem)',
                fontWeight: 300,
                color: 'var(--color-cream)',
                lineHeight: 1.2,
                marginBottom: '20px',
              }}>
                Built for the UAE,<br />
                <em className="gold-text">trusted worldwide</em>
              </h2>
              <p style={{ color: 'rgba(245,240,230,0.5)', fontSize: '0.95rem', lineHeight: 1.8, fontWeight: 300, marginBottom: '20px' }}>
                Shams Smart Services was founded in Dubai with a clear mission: make professional-grade AI image and document tools accessible to everyone — from freelancers in Deira to enterprises in DIFC.
              </p>
              <p style={{ color: 'rgba(245,240,230,0.5)', fontSize: '0.95rem', lineHeight: 1.8, fontWeight: 300, marginBottom: '32px' }}>
                Our tools are built with deep support for Arabic language and UAE government document standards, ensuring compliance and accuracy for local and regional users.
              </p>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {[
                  'UAE government document format support',
                  'Arabic-first OCR with 97.8% accuracy',
                  'GDPR & UAE PDPA compliant processing',
                  'Files auto-deleted after 30 minutes',
                ].map(f => (
                  <div key={f} style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <span style={{ color: 'rgba(201,150,30,0.8)' }}><IconCheck /></span>
                    <span style={{ fontSize: '0.875rem', color: 'rgba(245,240,230,0.6)', fontWeight: 300 }}>{f}</span>
                  </div>
                ))}
              </div>
            </AnimSection>
          </div>
        </div>
      </section>

      {/* CONTACT */}
      <ContactSection />

      {/* FOOTER */}
      <footer className="footer-bg" style={{ padding: '48px 0 32px' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 24px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '40px', marginBottom: '48px' }}>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
                <img src="/logo.png" alt="SSS Logo" style={{ width: "52px", height: "52px", borderRadius: "18px" }} />
                <span style={{ fontFamily: 'var(--font-heading)', fontWeight: 700, fontSize: '0.9rem', color: 'var(--color-cream)' }}>Shams Smart Services</span>
              </div>
              <p style={{ fontSize: '0.82rem', color: 'rgba(245,240,230,0.35)', lineHeight: 1.7, fontWeight: 300 }}>
                AI-powered tools for the modern UAE professional. Precise, fast, secure.
              </p>
            </div>

            <div>
              <p style={{ fontFamily: 'var(--font-heading)', fontSize: '0.72rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: 'rgba(201,150,30,0.6)', marginBottom: '14px' }}>Tools</p>
              {tools.map(t => (
                <a key={t.id} href={`#${t.id}`}
                  style={{ display: 'block', fontSize: '0.85rem', color: 'rgba(245,240,230,0.4)', textDecoration: 'none', marginBottom: '8px', fontWeight: 300, transition: 'color 0.2s' }}
                  onMouseEnter={e => (e.currentTarget.style.color = 'rgba(232,192,85,0.8)')}
                  onMouseLeave={e => (e.currentTarget.style.color = 'rgba(245,240,230,0.4)')}
                >{t.name}</a>
              ))}
            </div>

            <div>
              <p style={{ fontFamily: 'var(--font-heading)', fontSize: '0.72rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: 'rgba(201,150,30,0.6)', marginBottom: '14px' }}>Company</p>
              {['About', 'Blog', 'Careers', 'Press'].map(l => (
                <a key={l} href="#"
                  style={{ display: 'block', fontSize: '0.85rem', color: 'rgba(245,240,230,0.4)', textDecoration: 'none', marginBottom: '8px', fontWeight: 300, transition: 'color 0.2s' }}
                  onMouseEnter={e => (e.currentTarget.style.color = 'rgba(232,192,85,0.8)')}
                  onMouseLeave={e => (e.currentTarget.style.color = 'rgba(245,240,230,0.4)')}
                >{l}</a>
              ))}
            </div>

            <div>
              <p style={{ fontFamily: 'var(--font-heading)', fontSize: '0.72rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: 'rgba(201,150,30,0.6)', marginBottom: '14px' }}>Legal</p>
              {['Privacy Policy', 'Terms of Service', 'Cookie Policy', 'GDPR'].map(l => (
                <a key={l} href="#"
                  style={{ display: 'block', fontSize: '0.85rem', color: 'rgba(245,240,230,0.4)', textDecoration: 'none', marginBottom: '8px', fontWeight: 300, transition: 'color 0.2s' }}
                  onMouseEnter={e => (e.currentTarget.style.color = 'rgba(232,192,85,0.8)')}
                  onMouseLeave={e => (e.currentTarget.style.color = 'rgba(245,240,230,0.4)')}
                >{l}</a>
              ))}
            </div>
          </div>

          <div className="gold-line mb-6" />

          <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: '12px' }}>
            <p style={{ fontSize: '0.78rem', color: 'rgba(245,240,230,0.25)', fontWeight: 300 }}>
              © 2026 Shams Smart Services. All rights reserved. Dubai, UAE.
            </p>
            <p style={{ fontSize: '0.78rem', color: 'rgba(245,240,230,0.25)', fontWeight: 300, fontFamily: 'var(--font-display)', fontStyle: 'italic' }}>
              tools.shamswmalik.com
            </p>
          </div>
        </div>
      </footer>
      </>
  )
}
