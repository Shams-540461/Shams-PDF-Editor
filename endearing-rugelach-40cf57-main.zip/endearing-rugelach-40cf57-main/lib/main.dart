import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

ValueNotifier<ThemeMode> themeNotifier = ValueNotifier(ThemeMode.light);

void main() {
  runApp(const ShamsApp());
}

class ShamsApp extends StatelessWidget {
  const ShamsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (context, mode, child) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: "Shams Smart Services",
          themeMode: mode,
          theme: ThemeData(brightness: Brightness.light),
          darkTheme: ThemeData(brightness: Brightness.dark),
          home: const SplashScreen(),
        );
      },
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const MainScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A6B4F),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedContainer(
              duration: const Duration(seconds: 2),

              child: Image.asset(
                "assets/images/logo.png",
                height: 150,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              "Shams Smart Services",
              style: TextStyle(
                color: Colors.white,
                fontSize: 26,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              "Typing & Visa Services",
              style: TextStyle(color: Colors.white70, fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int currentIndex = 0;

  final pages = const [
    HomePage(),
    AboutUsPage(),
    ContactPage(),
    PrivacyPolicyPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: currentIndex,
        selectedItemColor: const Color(0xFF0A6B4F),
        unselectedItemColor: Colors.grey,

        showUnselectedLabels: true,

        selectedFontSize: 14,
        unselectedFontSize: 12,
        onTap: (index) {
          setState(() {
            currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: "About"),
          BottomNavigationBarItem(icon: Icon(Icons.contact_phone), label: "Contact"),
          BottomNavigationBarItem(icon: Icon(Icons.privacy_tip), label: "Privacy"),
        ],
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();

  String selectedService = "Visa Services";

  Future<void> openWhatsApp(String message) async {
    final url = Uri.parse(
      "https://wa.me/971568802521?text=${Uri.encodeComponent(message)}",
    );

    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    }
  }

  void sendServiceMessage() {
    final name = nameController.text.trim();
    final phone = phoneController.text.trim();

    if (name.isEmpty || phone.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Please enter your name and phone number"),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    final message = '''
Hi Shams Smart Services,

I need $selectedService.

Customer Details:
Name: $name
Phone: $phone
''';

    openWhatsApp(message);
  }

  @override
  void dispose() {
    nameController.dispose();
    phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar("Shams Smart Services"),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF0A6B4F), Color(0xFF1CBF73)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 40, 20, 20),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 24,
                ),
                child: Column(
                  children: [
                    Image.asset("assets/images/logo.png", height: 100),
                    const SizedBox(height: 12),
                    const Text(
                      "Welcome to Shams Smart Services",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      "Fast & Reliable Visa & Typing Services in Dubai and Across the UAE",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.black54),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              TextField(
                controller: nameController,
                decoration: fieldDecoration("Your Name", Icons.person),
              ),

              const SizedBox(height: 12),

              TextField(
                controller: phoneController,
                keyboardType: TextInputType.phone,
                decoration: fieldDecoration("Mobile Number", Icons.phone),
              ),

              const SizedBox(height: 12),

              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.black26),
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: selectedService,
                    isExpanded: true,
                    items: const [
                      DropdownMenuItem(value: "Visa Services", child: Text("Visa Services")),
                      DropdownMenuItem(value: "Emirates ID Service", child: Text("Emirates ID")),
                      DropdownMenuItem(value: "Medical Typing", child: Text("Medical Typing")),
                      DropdownMenuItem(value: "Document Typing", child: Text("Document Typing")),
                    ],
                    onChanged: (value) {
                      setState(() {
                        selectedService = value!;
                      });
                    },
                  ),
                ),
              ),

              const SizedBox(height: 20),

              SizedBox(
                width: double.infinity,
                height: 60,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF25D366),
                    foregroundColor: Colors.white,
                    elevation: 8,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(28),
                    ),
                  ),
                  onPressed: sendServiceMessage,
                  icon: const Icon(Icons.message, size: 28),
                  label: const Text(
                    "Get Service on WhatsApp",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class AboutUsPage extends StatelessWidget {
  const AboutUsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar("About Us"),
      body: const Padding(
        padding: EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Text(
            "Shams Smart Services\n\n"
            "We provide fast and reliable typing services in Dubai and across the UAE, including Visa Services, Emirates ID, Medical Typing and Document Typing.\n\n"
            "Customers can contact us directly through WhatsApp for quick support.",
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 16, height: 1.6),
          ),
        ),
      ),
    );
  }
}

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  Future<void> openLink(String link) async {
    final url = Uri.parse(link);

    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar("Contact"),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            ContactTile(
              icon: Icons.location_on,
              title: "Location",
              subtitle: "Dubai & Across UAE",
              onTap: () => openLink("https://www.google.com/maps/search/Dubai+UAE"),
            ),
            const SizedBox(height: 14),
            ContactTile(
              icon: Icons.phone,
              title: "Call Now",
              subtitle: "+971568802521",
              onTap: () => openLink("tel:+971568802521"),
            ),
            const SizedBox(height: 14),
            ContactTile(
              icon: Icons.chat,
              title: "WhatsApp",
              subtitle: "Instant WhatsApp Support",
              onTap: () => openLink("https://wa.me/971568802521"),
            ),
          ],
        ),
      ),
    );
  }
}

class PrivacyPolicyPage extends StatelessWidget {
  const PrivacyPolicyPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar("Privacy Policy"),
      body: const Padding(
        padding: EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Text(
            "Privacy Policy\n\n"
            "Shams Smart Services values your privacy. We do not collect or store personal information on our servers.\n\n"
            "Customer information entered in the app is only used for WhatsApp communication.\n\n"
            "The app may open external applications such as WhatsApp and Google Maps for communication and support purposes.\n\n"
            "By using this app, you agree to this privacy policy.",
            style: TextStyle(fontSize: 16, height: 1.6),
          ),
        ),
      ),
    );
  }
}

class ContactTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const ContactTile({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        onTap: onTap,
        leading: CircleAvatar(
          backgroundColor: const Color(0xFFE8F5F0),
          child: Icon(icon, color: const Color(0xFF0A6B4F)),
        ),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.arrow_forward_ios, size: 18),
      ),
    );
  }
}

PreferredSizeWidget customAppBar(String title) {
  return AppBar(
    title: Text(title),
    centerTitle: true,
    backgroundColor: const Color(0xFF0A6B4F),
    foregroundColor: Colors.white,
    actions: [
      IconButton(
        icon: const Icon(Icons.dark_mode),
        onPressed: () {
          themeNotifier.value =
              themeNotifier.value == ThemeMode.light ? ThemeMode.dark : ThemeMode.light;
        },
      ),
    ],
  );
}

InputDecoration fieldDecoration(String label, IconData icon) {
  return InputDecoration(
    filled: true,
    fillColor: Colors.white.withOpacity(0.95),
    labelText: label,
    prefixIcon: Icon(icon),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(28),
    ),
  );
}